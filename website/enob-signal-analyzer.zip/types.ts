
export interface SignalPoint {
  index: number;
  value: number;
}
